
package p01_java_swing;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author alumno
 */
public class Empresa {
    
   private ArrayList<Empleado> empleados = new ArrayList<Empleado>(); 
   
   
   public void addEmpleado(String nombre, Double salario, LocalDate fechaNac){
   
   Empleado e = new Empleado(nombre, fechaNac, salario);
   empleados.add(e);
   
   
   }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }
}
