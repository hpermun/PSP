package p01_java_swing;

import java.time.LocalDate;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Datos extends JFrame {
    // Datos de los empleados
    private String[] nombres = {"Marcos", "Fran", "Ana", "Julian", "Laura"};
    private double[] salarios = {1650.00, 1720.00, 1250.00, 1460.00, 1350.00};
    private LocalDate[] fechasNac = {
        LocalDate.of(1998, 5, 1),
        LocalDate.of(1989, 2, 27),
        LocalDate.of(2000, 7, 8),
        LocalDate.of(2001, 10, 6),
        LocalDate.of(1996, 1, 21)
    };

    private int indice = 0;

    private TextField nombreField;
    private TextField fechaNacField;
    private TextField salarioField;

    public Datos() {
        super("Datos de Empleados");

        // Botones
        JButton btnInicio = new JButton("Inicio");
        btnInicio.addActionListener(e -> mostrarEmpleado(0));

        JButton btnAtras = new JButton("<-");
        btnAtras.addActionListener(e -> mostrarEmpleadoAnterior());

        JButton btnAdelante = new JButton("->");
        btnAdelante.addActionListener(e -> mostrarEmpleadoSiguiente());

        JButton btnFin = new JButton("Fin");
        btnFin.addActionListener(e -> mostrarEmpleado(nombres.length - 1));

        // Campos de texto
        nombreField = new TextField(20);
        nombreField.setEditable(false);
        nombreField.setForeground(Color.red);

        fechaNacField = new TextField(20);
        fechaNacField.setEditable(false);
        fechaNacField.setForeground(Color.red);

        salarioField = new TextField(20);
        salarioField.setEditable(false);
        salarioField.setForeground(Color.red);

        // Panel de campos
        JPanel panelCampos = new JPanel(new GridLayout(3, 2));
        panelCampos.add(new JLabel("Nombre: "));
        panelCampos.add(nombreField);
        panelCampos.add(new JLabel("Fecha de Nacimiento: "));
        panelCampos.add(fechaNacField);
        panelCampos.add(new JLabel("Salario: "));
        panelCampos.add(salarioField);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnInicio);
        panelBotones.add(btnAtras);
        panelBotones.add(btnAdelante);
        panelBotones.add(btnFin);

        // Configurar el layout
        setLayout(new BorderLayout());
        add(panelCampos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Mostrar el primer empleado al iniciar
        mostrarEmpleado(indice);
    }

    private void mostrarEmpleado(int index) {
        indice = index;
        nombreField.setText(nombres[indice]);
        fechaNacField.setText(fechasNac[indice].toString());
        salarioField.setText(String.valueOf(salarios[indice]));
    }

    private void mostrarEmpleadoSiguiente() {
        if (indice < nombres.length - 1) {
            mostrarEmpleado(indice + 1);
        }
    }

    private void mostrarEmpleadoAnterior() {
        if (indice > 0) {
            mostrarEmpleado(indice - 1);
        }
    }

    public static void main(String[] args) {
        Datos app = new Datos();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.pack();
        app.setVisible(true);
    }
}

